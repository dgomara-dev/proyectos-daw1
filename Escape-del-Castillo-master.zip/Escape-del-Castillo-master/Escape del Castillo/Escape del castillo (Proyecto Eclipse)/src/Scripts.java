public class Scripts {
	// Respuestas con "usar" (Scripts del uso de los objetos).
	public static void answerUsar(String[] inputVector, int total) {
		if (total == 0) {
			System.out.println("\t�Usar el qu�?");
		}
		else {
			switch (inputVector[1]) {
				case "calavera":
					if (Main.r0.getName().equals("Sal�n del trono") && Main.i1.getPickedUp()==true) {
						try {
							System.out.println("\tColocas la calavera en el esqueleto del trono.");
							Thread.sleep(2000);
							System.out.println("\t...");
							Thread.sleep(2000);
							System.out.println("\t*�Crack!*");
							Thread.sleep(2000);
							System.out.println("\t...");
							Thread.sleep(2000);
							System.out.println("\tEl esqueleto, ya completo, se endereza en su trono.");
							Thread.sleep(4000);
							System.out.println("\n\n\tPor un momento te da la impresi�n de que el antiguo rey demonio te ha sonre�do.");
							Thread.sleep(5000);
							for (int i=0; i<20; i++) {
								System.out.println("\n");
								Thread.sleep(200);
							}
							System.out.println("\n\n\n\n\t\t\t\t\t\t\t2017 - Daniel G�mara");
							for (int i=0; i<20; i++) {
								System.out.println("\n");
								Thread.sleep(200);
							}
							System.out.println("\n\n\n\n\t\t\t\t\t\t\tGracias por jugar.\n");
							Thread.sleep(5000);
							System.exit(0);	
						} catch (InterruptedException e){}
					}
					else {
						lastAnswerUsar(Main.i1);
					}
				break;
				case "cubo":
					if (Main.r0.getName().equals("Fuente") && Main.i2.getPickedUp()==true && Main.i2.getTurnedOn()==false) {
						try {
							System.out.println("\t...");
							Thread.sleep(1000);
							System.out.println("\tLlenas el cubo de agua de la fuente.");
						} catch (InterruptedException e){}
						Main.i2.setName("Cubo lleno de agua");
						Main.i2.setDescription("\tUn cubo abollado y corro�do por el �xido, lleno de agua hasta los topes.");
						Main.i2.setTurnedOn(true);
					}
					else if (Main.r0.getName().equals("Sala en llamas") && Main.r5.getBlocked()==true && Main.i2.getPickedUp()==true && Main.i2.getTurnedOn()==true) {
						try {
							System.out.println("\tEchas el cubo de agua a las llamas.");
							Thread.sleep(1000);
							System.out.println("\t*�FLUSH!*");
							Thread.sleep(1000);
							System.out.println("\tEl incendio se ha apagado. Una llave dorada brilla entre las cenizas.");
						} catch (InterruptedException e){}
						Main.i2.setName("Cubo");
						Main.i2.setDescription("\tUn cubo abollado y corro�do por el �xido.\n\tPese a su deplorable aspecto puede transportar agua como en sus mejores d�as.");
						Main.i2.setTurnedOn(false);
						Main.r5.setDescription("\tLa habitaci�n ya no alberga fuego alguno, aunque un penetrante olor a quemado impregna el lugar.");
						Main.r5.setDescriptionItem("\n\tUna llave dorada brilla entre las cenizas.");
						Main.r5.setBlocked(false);	
					}
					else {
						lastAnswerUsar(Main.i2);
					}
				break;
				case "llave":
					if (Main.r0.getName().equals("Armer�a") && Main.i3.getPickedUp()==true && Main.i3.getTurnedOn()==false && Main.i4.getPickedUp()==false) {
						try {
							System.out.println("\tUsas la llave en la vitrina.");
							Thread.sleep(1000);
							System.out.println("\t*�Click!*");
							Thread.sleep(1000);
							System.out.println("\tLa llave gira perfectamente en el cerrojo, la vitrina est� ahora abierta.");
						} catch (InterruptedException e){}
						Main.i3.setTurnedOn(true);
						Main.r6.setDescriptionItem("\n\tLa vitrina que guardaba el hacha est� ahora abierta.");
					}
					else {
						lastAnswerUsar(Main.i3);
					}
				break;
				case "hacha":
					if (Main.r0.getName().equals("Esfinge") && Main.r7.getBlocked()==true && Main.i4.getPickedUp()==true) {
						try {
							System.out.println("\tTe l�as a hachazos contra el muro de madera.");
							Thread.sleep(1000);
							System.out.println("\t...");
							Thread.sleep(1000);
							System.out.println("\tEl camino est� despejado, ya se puede entrar.");
							Thread.sleep(1000);
						} catch (InterruptedException e){}
						Main.r7.setDescription("\tUna gran esfinge de piedra te mira a los ojos, intentando ver dentro de t�.\n\t��Qu� tres cosas teme todo hombre sabio?�");
						Main.r7.setBlocked(false);	
						System.out.println("\n\n\t- LUGAR:  "+Main.r0.getName()+"\n"+Main.r0.getDescription());
					}
					else {
						lastAnswerUsar(Main.i4);
					}
				break;
				case "libro":
					if (Main.r0.getName().equals("Esfinge") && Main.i5.getPickedUp()==true && Main.i6.getPickedUp()==false && Main.r7.getBlocked()==false) {
						try {
							System.out.println("\tCoges el libro y recitas:");
							Thread.sleep(2000);
							System.out.print("\t�Todo hombre sabio teme tres cosas:");
							Thread.sleep(1000);
							System.out.print(" la tormenta en el mar,");
							Thread.sleep(1000);
							System.out.print(" la noche sin luna");
							Thread.sleep(1000);
							System.out.println(" y la ira de un hombre amable.�");
							Thread.sleep(2000);
							System.out.println("\t...");
							Thread.sleep(1000);
							System.out.println("\t�Correcto. He aqu� tu galard�n.�");
							Thread.sleep(1000);
						} catch (InterruptedException e){}
						Main.i6.addInventory();
						Main.r7.setDescription("\tLa esfinge descansa inm�vil con los ojos cerrados.");
					}
					else {
						lastAnswerUsar(Main.i5);
					}
				break;
				case "rosa":
					if (Main.r0.getName().equals("Sala central") && Main.i6.getPickedUp()==true) {
						try {
							System.out.println("\tColocas la rosa de los vientos en el centro de la mesa.");
							Thread.sleep(1000);
							System.out.print("\t...");
							Thread.sleep(1000);
							System.out.print(" ...");
							Thread.sleep(1000);
							System.out.println(" ...");
							Thread.sleep(2000);
							System.out.println("\t*�BUM!*");
							Thread.sleep(2000);
							System.out.println("\tEl suelo de la sala se ha venido abajo.");
							Thread.sleep(2000);							
						} catch (InterruptedException e){}
						Room.travel(Main.r9);
						if (Main.i1.getPickedUp() == true) {
							Main.r9.setPickedUp(true);
						}
					}
					else {
						lastAnswerUsar(Main.i5);
					}
				break;
				default:
					System.out.println("\tNo te entiendo...");
			}
		}
	}
	public static void lastAnswerUsar(Item item) {
		if (item.getPickedUp()==true) {
			System.out.println("\tInteresante idea...");
		}
		else {
			System.out.println("\tNo te entiendo...");
		}
	}
}
