import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Toolkit;
import java.util.Scanner;

public class Main {
	
	// Habitaciones
	public static Room r0 = new Room();
	public static Room rX = new Room();
	public static Room r1 = new Room("Entrada", "\tTe encuentras en una habitaci�n de piedra, fr�a y oscura.", "\n\tPor el Norte vas a la sala central, por el Este sales al jard�n y por el Oeste llegas a la fuente.", "\n\tUna extra�a calavera yace en el suelo.");
	public static Room r2 = new Room("Fuente", "\tEs un cuarto fresco y relajante, iluminado por una tenue luz azul.\n\tEn la pared hay una fuente de la que brota un chorro de agua cristalina.", "\n\tPor el Este vuelves a la entrada, por el Norte llegas a la armer�a.");
	public static Room r3 = new Room("Jard�n", "\tEs un peque�o jard�n abierto, donde unos descuidados setos se elevan hacia el cielo.", "\n\tPor el Oeste vuelves a la entrada, por el Norte entras a la biblioteca.", "\n\tParece que alguien se ha dejado olvidado un viejo cubo met�lico.");
	public static Room r4 = new Room("Sala central", "\tEs una gran sala abovedada, con altas columnas soportando la estructura.\n\tUna mesa con los puntos cardinales ocupa el centro de la estancia.", "\n\tPor el Norte est� a la armer�a, por el Sur vuelves a la entrada, por el Este la sala en llamas, por el Oeste la esfinge.");
	public static Room r5 = new Room("Sala en llamas", "\tEst�s en una habitaci�n ardiendo, el calor es casi insoportable.", "\n\tPor el Oeste vuelves a la sala central.", true);
	public static Room r6 = new Room("Armer�a", "\tEst�s en un peque�o almac�n, repleto de todo tipo de armamento b�lico.", "\n\tPor el Sur vuelves a la sala central, por el Este llegas a la biblioteca, por el Oeste vas a la fuente.", "\n\tUna vitrina cerrada guarda un hacha de aspecto antiguo.");
	public static Room r7 = new Room("Esfinge", "\tUn muro de madera bloquea el avance.", "\n\tPor el Este vuelves a la sala central.", true);
	public static Room r8 = new Room("Biblioteca", "\tTe encuentras en un viejo archivo, iluminado por l�mparas de luz rojiza.", "\n\tPor el Oeste llegas a la armer�a y por el Sur sales al jard�n.", "\n\tUn antiguo libro descansa encima de una mesa.");
	public static Room r9 = new Room("Sal�n del trono", "\tTe encuentras en un antiguo sal�n, desde donde ya olvidadas dinast�as gobernaban esta tierra.\n\tUn rayo de luz ilumina un sobrio trono de hierro en el que descansa un esqueleto sin cabeza.", "", "\n\tUna calavera rueda junto a tu pie... A saber de d�nde habr� salido.");

	
	// �tems

	public static Item i1 = new Item("Calavera", "\tUna antigua calavera a la que le falta la mand�bula.\n\tDos cuernos surgen de las sienes, como si de una bestia se tratara.");
	public static Item i2 = new Item("Cubo", "\tUn cubo abollado y corro�do por el �xido.\n\tPese a su deplorable aspecto, puede transportar agua como en sus mejores d�as.");
	public static Item i3 = new Item("Llave", "\tUna peque�a llave, tan chamuscada que a penas se ve su brillo dorado.\n\tTiene pinta de abrir algo como un cofre o una vitrina.");
	public static Item i4 = new Item("Hacha", "\tUn gran hacha de guerra, con antiguas runas grabadas en su superficie.\n\tAunque fue forjada para la batalla puede usarse para tareas m�s mundanas.");
	public static Item i5 = new Item("Libro", "\t�El Temor de un Hombre Sabio�, de Patrick Rothfuss.");
	public static Item i6 = new Item("Rosa de los vientos", "\tUn antiqu�simo instrumento de navegaci�n, con una flor de lis se�alando el Norte.\n\tParece encajar en alguna parte.");

	
	// Otros
	public static boolean repeat;
	public static JFrame ventana;
	

	// Inicio
	public static void start() {
		Scanner sc = new Scanner(System.in);
		
		ventana = new JFrame("Escape del castillo - MAPA");
		ventana.setAlwaysOnTop(false);
		ventana.setResizable(false);
		ventana.setIconImage(Toolkit.getDefaultToolkit().getImage(Main.class.getResource("/img/iconoMapa.png")));
		ventana.setBounds(100, 100, 1145, 621);
		ventana.getContentPane().setLayout(null);
		
		JLabel fondo = new JLabel("Fondo");
		fondo.setLabelFor(fondo);
		fondo.setBounds(0, 0, 1140, 592);
		fondo.setIcon(new ImageIcon(Main.class.getResource("/img/mapa.png")));
		ventana.getContentPane().add(fondo);
		
		System.out.println("\n\n"
				+ "\t\t\t             .                                                      .              \n"
				+ "\t\t\t           .n                   .                 .                  n.            \n"
				+ "\t\t\t     .   .dP                  dP                   9b                 9b.    .     \n"
				+ "\t\t\t    4    qXb         .       dX                     Xb       .        dXp     t    \n"
				+ "\t\t\t   dX.    9Xb      .dXb    __                         __    dXb.     dXP     .Xb   \n"
				+ "\t\t\t   9XXb._       _.dXXXXb dXXXXbo.                 .odXXXXb dXXXXb._       _.dXXP   \n"
				+ "\t\t\t    9XXXXXXXXXXXXXXXXXXXVXXXXXXXXOo.           .oOXXXXXXXXVXXXXXXXXXXXXXXXXXXXP    \n"
				+ "\t\t\t     `9XXXXXXXXXXXXXXXXXXXXX'~   ~`OOO8b   d8OOO'~   ~`XXXXXXXXXXXXXXXXXXXXXP'     \n"
				+ "\t\t\t       `9XXXXXXXXXXXP' `9XX'    *X*   `98v8P'   *X*   `XXP' `9XXXXXXXXXXXP'        \n"
				+ "\t\t\t           ~~~~~~~       9X.          .db|db.          .XP       ~~~~~~~           \n"
				+ "\t\t\t                          )b.  .dbo.dP'`v'`9b.odb.  .dX(                          \n"
				+ "\t\t\t                         ,dXXXXXXXXXXXb     dXXXXXXXXXXXb.                         \n"
				+ "\t\t\t                        dXXXXXXXXXXXP'   .   `9XXXXXXXXXXXb                        \n"
				+ "\t\t\t                       dXXXXXXXXXXXXb   d|b   dXXXXXXXXXXXX                        \n"
				+ "\t\t\t                       9XXb'   `XXXXXb.dX|Xb.dXXXXX'   `dXXP                       \n"
				+ "\t\t\t                        `'      9XXXXXX(   )XXXXXXP      `'                        \n"
				+ "\t\t\t                                 XXXX X.`v'.X XXXX                                 \n"
				+ "\t\t\t                                XP^X'`b   d'`X^XX                                 \n"
				+ "\t\t\t                                 X. 9  `   '  P )X                                 \n"
				+ "\t\t\t                                 `b  `       '  d'                                 \n"
				+ "\t\t\t                                  `             '                                  \n");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e){}
		System.out.println("\n\n\t\t\t\t\t\t     Pulsa ENTER para empezar");
		sc.nextLine();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e){}
		
		r0 = r1;
	}
	
	
	// Repetici�n
	public static void update() {
		while (true) {
			repeat = true;
			System.out.println("\n\n\t- LUGAR:  "+r0.getName()+"\n"+r0.getDescription());
			while (repeat == true) {
				Answer.answers();
			}
		}
	}
	
	
	// M�todo principal
	public static void main(String args[]) {
		start();
		update();
	}
}