public class Room {
	private String name;					// Nombre de la sala
	private String description;				// Descripci�n de la sala
	private String descriptionExit;			// Descripci�n de las salidas de la sala
	private String descriptionItem;			// Descripci�n del �tem en el contexto de la sala
	private boolean pickedUp;				// Bandera para saber si se ha cogido el �tem de la sala
	private boolean blocked;				// Bandera para saber si una sala est� bloqueada

	
	// Constructor de la salas auxiliares
	public Room() {
		name = "Auxiliar";
	}
	
	
	// Constructor de salas sin �tem
	public Room(String name, String description, String descriptionExit) {
		this.name = name;
		this.description = description;
		this.descriptionExit = descriptionExit;
		descriptionItem = "";
		pickedUp = false;
		blocked = false;
	}
	
	
	// Constructor de salas bloqueadas
	public Room(String name, String description, String descriptionExit, boolean blocked) {
		this.name = name;
		this.description = description;
		this.descriptionExit = descriptionExit;
		descriptionItem = "";
		pickedUp = false;
		this.blocked = blocked;
	}
	
	
	// Constructor completo
	public Room(String name, String description, String descriptionExit, String descriptionItem) {
		this.name = name;
		this.description = description;
		this.descriptionExit = descriptionExit;
		this.descriptionItem = descriptionItem;
		pickedUp = false;
		blocked = false;
	}
	
	
	// Obtener el nombre de la sala
	public String getName() {
		return name;
	}
	
	
	// Obtener una descripci�n de la sala, variable seg�n si se ha recogido el �tem o no
	public String getDescription() {
		if (pickedUp == true) {
			return description + descriptionExit;
		}
		else {
			return description + descriptionItem + descriptionExit;
		}
	}
	
	
	// Obtener estado la sala, bloqueada o no
	public boolean getPickedUp() {
		return pickedUp;
	}
	
	
	// Obtener estado la sala, bloqueada o no
	public boolean getBlocked() {
		return blocked;
	}
	
	
	// Cambiar la descripci�n
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	// Cambiar la descripci�n del objeto en la sala
	public void setDescriptionItem(String descriptionItem) {
		this.descriptionItem = descriptionItem;
	}
	
	
	// Cambiar la bandera cuando se recoja el �tem
	public void setPickedUp(Boolean pickedUp) {
		this.pickedUp = pickedUp;
	}
	
	
	// Cambiar el estado de la sala, bloqueada o no
	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}
	
	
	// Viajar de una sala a otra
	public static void travel(Room room) {
		if (room.getName().equals("Auxiliar")) {
			System.out.println("\tNo se puede pasar.");
		}
		else {
			Main.r0 = room;
			Main.repeat = false;
		}
	}	
}