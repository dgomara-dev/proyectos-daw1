import java.util.Scanner;

public class Answer {
	
	// Selector de m�todos seg�n la primera palabra de la frase
	public static void answers() {
		Scanner sc = new Scanner(System.in);
		String input;
		String inputVector[] = new String [100];
		int total = 0;
		
		System.out.print("\n\t> ");
		input = sc.nextLine();
		inputVector = input.split(" ");
		while (total<inputVector.length-1) {
			total++;
		}
		switch (inputVector[0]) {
			case "mirar":
				answerMirar(inputVector, total);
			break;
			case "coger":
				answerCoger(inputVector, total);
			break;
			case "ir":
				answerIr(inputVector, total);
			break;
			case "usar":
				Scripts.answerUsar(inputVector, total);
			break;
			default:
				answerOther(inputVector);
		}
	}
	
	
	
	// Respuestas con "mirar"
	public static void answerMirar(String[] inputVector, int total) {
		if (total == 0) {
			System.out.println("\t�Mirar el qu�?");
		}
		else if (total == 1) {
			switch (inputVector[1]) {
				case "sala":
					System.out.println(Main.r0.getDescription());
				break;
				case "calavera":
					if (Main.r0.getName().equals("Entrada")) {
						setAnswerMirar(inputVector, Main.i1, "Entrada");
					}
					else {
						setAnswerMirar(inputVector, Main.i1, "Sal�n del trono");
					}
				break;
				case "cubo":
					setAnswerMirar(inputVector, Main.i2, "Jard�n");
				break;
				case "llave":
					if (Main.r5.getBlocked() == false) {
						setAnswerMirar(inputVector, Main.i3, "Sala en llamas");
					}
					else {
						System.out.println("\tNo te entiendo...");
					}
				break;
				case "hacha":
					setAnswerMirar(inputVector, Main.i4, "Armer�a");
					if (Main.i3.getTurnedOn() == false) {
						System.out.println("\tEst� guardada bajo candado en una vitrina de cristal.");
					}
				break;
				case "libro":
					setAnswerMirar(inputVector, Main.i5, "Biblioteca");
				break;
				case "rosa":
					setAnswerMirar(inputVector, Main.i6, "");
				break;
				case "esqueleto":
					if (Main.r0.getName().equals("Sal�n del trono")) {
						System.out.println("\t�No te rindas! �Esqueleto!");
					}
					else {
						System.out.println("\tNo te entiendo...");
					}
				break;
				default:
					System.out.println("\tNo te entiendo...");
			}
		}
		else {
			System.out.println("\tNo te entiendo...");
		}
	}
	public static void setAnswerMirar(String[] inputVector, Item item, String roomName) {
		if ((Main.r0.getName().equals(roomName) && item.getPickedUp()==false) || item.getPickedUp()==true) {
			System.out.println(item.getDescription());
		}
		else {
			System.out.println("\tNo te entiendo...");
		}
	}
	
	
	
	// Respuestas con "coger"
	public static void answerCoger(String[] inputVector, int total) {
		if (total == 0) {
			System.out.println("\t�Coger el qu�?");
		}
		else {
			switch (inputVector[1]) {
				case "calavera":
					if (Main.r0.getName().equals("Entrada")) {
						setAnswerCoger(inputVector, Main.i1, Main.r1, "Entrada");
					}
					else {
						setAnswerCoger(inputVector, Main.i1, Main.r9, "Sal�n del trono");
					}
				break;
				case "cubo":
					setAnswerCoger(inputVector, Main.i2, Main.r3, "Jard�n");
				break;
				case "llave":
					if (Main.r5.getBlocked() == false) {
						setAnswerCoger(inputVector, Main.i3, Main.r5, "Sala en llamas");
					}
					else {
						System.out.println("\tNo te entiendo...");
					}
				break;
				case "hacha":
					if (Main.i3.getTurnedOn()==true) {
						setAnswerCoger(inputVector, Main.i4, Main.r6, "Armer�a");
					}
					else {
						System.out.println("\tInteresante idea...");
					}
				break;
				case "libro":
					setAnswerCoger(inputVector, Main.i5, Main.r8, "Biblioteca");
				break;			
				default:
					System.out.println("\tNo te entiendo...");
			}
		}
	}
	public static void setAnswerCoger(String[] inputVector, Item item, Room room, String roomName) {
		if (Main.r0.getName().equals(roomName) && item.getPickedUp()==false) {
			item.addInventory();
			room.setPickedUp(true);
		}
		else {
			System.out.println("\tNo te entiendo...");
		}
	}

	

	// Respuestas con "ir"
	public static void answerIr(String[] inputVector, int total) {
		if (total == 0) {
			System.out.println("\t�Ir a d�nde?");
		}
		else {
			switch (Main.r0.getName()) {
				case "Entrada":
					setAnswerIr(inputVector, Main.r4, Main.rX, Main.r3, Main.r2);
				break;
				case "Fuente":
					setAnswerIr(inputVector, Main.r6, Main.rX, Main.r1, Main.rX);
				break;
				case "Jard�n":
					setAnswerIr(inputVector, Main.r8, Main.rX, Main.rX, Main.r1);
				break;
				case "Sala central":
					setAnswerIr(inputVector, Main.r6, Main.r1, Main.r5, Main.r7);
				break;
				case "Esfinge":
					setAnswerIr(inputVector, Main.rX, Main.rX, Main.r4, Main.rX);
				break;
				case "Sala en llamas":
					setAnswerIr(inputVector, Main.rX, Main.rX, Main.rX, Main.r4);
				break;
				case "Armer�a":
					setAnswerIr(inputVector, Main.rX, Main.r4, Main.r8, Main.r2);
				break;
				case "Biblioteca":
					setAnswerIr(inputVector, Main.rX, Main.r3, Main.rX, Main.r6);
				break;
				case "Sal�n del trono":
					setAnswerIr(inputVector, Main.rX, Main.rX, Main.rX, Main.rX);
				break;
				default:
					System.out.println("\tNo te entiendo...");
			}
		}
	}
	public static void setAnswerIr(String[] inputVector, Room norte, Room sur, Room este, Room oeste)  {
		switch (inputVector[1]) {
			case "norte":
				Room.travel(norte);
			break;
			case "sur":
				Room.travel(sur);
			break;
			case "este":
				Room.travel(este);
			break;
			case "oeste":
				Room.travel(oeste);
			break;
			default:
				System.out.println("\tNo te entiendo...");
		}
	}

	
	
	// Otras respuestas
	public static void answerOther(String[] inputVector) {
		Scanner sc = new Scanner(System.in);
		String input;
		
		switch (inputVector[0]) {
			case "salir":
				System.out.print("\t�De verdad quieres salir?\n\t> ");
				input = sc.nextLine();
				if (input.equals("salir") || input.equals("si")) {
					System.out.println("\n\n\t\t\t\t\t\t\t�Nos vemos pronto!\n");
					try {
						Thread.sleep(3000);
					} catch (InterruptedException e){}
					System.exit(0);
				}
				else if (input.equalsIgnoreCase("no")) {
					System.out.println("\tBuf, �menos mal!");
				}
				else {
					System.out.println("\tNo te entiendo...");
				}
			break;
			case "inventario":
				if (Main.i1.getPickedUp()==false && Main.i2.getPickedUp()==false && Main.i3.getPickedUp()==false && Main.i4.getPickedUp()==false && Main.i5.getPickedUp()==false && Main.i6.getPickedUp()==false) {
					System.out.println("\tInventario vac�o.\n\tPrueba a coger algo.");
				}
				else {
					if (Main.i1.getPickedUp() == true) {
						System.out.println("\t    - "+Main.i1.getName());
					}
					if (Main.i2.getPickedUp() == true) {
						System.out.println("\t    - "+Main.i2.getName());
					}
					if (Main.i3.getPickedUp() == true) {
						System.out.println("\t    - "+Main.i3.getName());
					}
					if (Main.i4.getPickedUp() == true) {
						System.out.println("\t    - "+Main.i4.getName());
					}
					if (Main.i5.getPickedUp() == true) {
						System.out.println("\t    - "+Main.i5.getName());
					}
					if (Main.i6.getPickedUp() == true) {
						System.out.println("\t    - "+Main.i6.getName());
					}
				}
			break;
			case "mapa":
				System.out.println("\tAbriendo mapa...");
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e){}
				Main.ventana.setVisible(true);
			break;
			default:
				System.out.println("\tNo te entiendo...");
		}
	}
}
