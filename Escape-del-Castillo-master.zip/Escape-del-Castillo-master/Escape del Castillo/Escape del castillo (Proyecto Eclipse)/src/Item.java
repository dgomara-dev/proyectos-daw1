public class Item {
	private String name;				// Nombre del �tem
	private String description;			// Descripci�n del �tem
	private boolean pickedUp;			// Bandera para saber si se ha recogido el �tem
	private boolean turnedOn;			// Bandera especial para los objetos que tienen dos estados. De momento s�lo lo usa el cubo (lleno o vac�o) y la llave (usada o no)
	
	
	// Constructor
	public Item(String name, String description) {
		this.name = name;
		this.description = description;
		pickedUp = false;
		turnedOn = false;
	}
	
	
	// Obtener el nombre del �tem
	public String getName() {
		return name;
	}
	
	
	// Obtener descripci�n del �tem
	public String getDescription() {
		return description;
	}
	
	
	// Obtener estado del �tem, recogido o no
	public boolean getPickedUp() {
		return pickedUp;
	}
	
	
	// Obtener estado del �tem, activado o no
	public boolean getTurnedOn() {
		return turnedOn;
	}
	
	
	// Cambiar el nombre del �tem
	public void setName(String name) {
		this.name = name;
	}
	
	
	// Cambiar la descripci�n del �tem
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	// Cambiar el estado del �tem, activado o no
	public void setTurnedOn(boolean turnedOn) {
		this.turnedOn = turnedOn;
	}
	
	
	// A�adir objeto al inventario
	public void addInventory() {
		pickedUp = true;
		System.out.println("\t"+getName()+" a�adido/a al inventario.");
	}
}