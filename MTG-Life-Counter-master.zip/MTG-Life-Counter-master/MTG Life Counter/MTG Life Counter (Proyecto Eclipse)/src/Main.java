import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;



public class Main {
	
	private JFrame frame;
	private JLabel lblBackground1;
	private JLabel lblBackground2;
	private int life1;
	private int life2;
	private int background1;
	private int background2;

	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	public Main() {
		life1 = 20;
		life2 = 20;
		do {
			background1 = (int)((Math.random() * 5));
			background2 = (int)((Math.random() * 5));
		} while (background1 == background2);		
		initialize();
	}


	
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(128, 128, 630, 349);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JLabel lblLife1 = new JLabel(""+life1);
		lblLife1.setForeground(Color.WHITE);
		lblLife1.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 80));
		lblLife1.setHorizontalAlignment(SwingConstants.CENTER);
		lblLife1.setBounds(80, 75, 150, 100);
		frame.getContentPane().add(lblLife1);
		
		
		JLabel lblLife2 = new JLabel(""+life2);
		lblLife2.setForeground(Color.WHITE);
		lblLife2.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 80));
		lblLife2.setHorizontalAlignment(SwingConstants.CENTER);
		lblLife2.setBounds(394, 75, 150, 100);
		frame.getContentPane().add(lblLife2);
		
		
		JLabel lblPoison1 = new JLabel(""+0);
		lblPoison1.setForeground(Color.WHITE);
		lblPoison1.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 40));
		lblPoison1.setHorizontalAlignment(SwingConstants.CENTER);
		lblPoison1.setBounds(118, 190, 75, 75);
		frame.getContentPane().add(lblPoison1);
		
		
		JLabel lblPoison2 = new JLabel(""+0);
		lblPoison2.setForeground(Color.WHITE);
		lblPoison2.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 40));
		lblPoison2.setHorizontalAlignment(SwingConstants.CENTER);
		lblPoison2.setBounds(430, 190, 75, 75);
		frame.getContentPane().add(lblPoison2);
		
		
		JButton btnAddLife1 = new JButton(">");
		btnAddLife1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				life1++;
				lblLife1.setText(""+life1);
			}
		});
		btnAddLife1.setForeground(Color.WHITE);
		btnAddLife1.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 60));
		btnAddLife1.setOpaque(false);
		btnAddLife1.setContentAreaFilled(false);
		btnAddLife1.setBorderPainted(false);
		btnAddLife1.setFocusPainted(false);
		btnAddLife1.setBounds(212, 75, 100, 100);
		frame.getContentPane().add(btnAddLife1);
		
		
		JButton btnAddLife2 = new JButton(">");
		btnAddLife2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				life2++;
				lblLife2.setText(""+life2);
			}
		});
		btnAddLife2.setForeground(Color.WHITE);
		btnAddLife2.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 60));
		btnAddLife2.setOpaque(false);
		btnAddLife2.setContentAreaFilled(false);
		btnAddLife2.setBorderPainted(false);
		btnAddLife2.setFocusPainted(false);
		btnAddLife2.setBounds(524, 75, 100, 100);
		frame.getContentPane().add(btnAddLife2);
		
		
		JButton btnRemoveLife1 = new JButton("<");
		btnRemoveLife1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				life1--;
				lblLife1.setText(""+life1);
			}
		});
		btnRemoveLife1.setForeground(Color.WHITE);
		btnRemoveLife1.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 60));
		btnRemoveLife1.setOpaque(false);
		btnRemoveLife1.setContentAreaFilled(false);
		btnRemoveLife1.setBorderPainted(false);
		btnRemoveLife1.setFocusPainted(false);
		btnRemoveLife1.setBounds(0, 75, 100, 100);
		frame.getContentPane().add(btnRemoveLife1);
		
		
		JButton btnRemoveLife2 = new JButton("<");
		btnRemoveLife2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				life2--;
				lblLife2.setText(""+life2);
			}
		});
		btnRemoveLife2.setForeground(Color.WHITE);
		btnRemoveLife2.setFont(new Font("Matura MT Script Capitals", Font.PLAIN, 60));
		btnRemoveLife2.setOpaque(false);
		btnRemoveLife2.setContentAreaFilled(false);
		btnRemoveLife2.setBorderPainted(false);
		btnRemoveLife2.setFocusPainted(false);
		btnRemoveLife2.setBounds(312, 75, 100, 100);
		frame.getContentPane().add(btnRemoveLife2);
		
		
		JSlider sliderPoison1 = new JSlider(JSlider.HORIZONTAL, 0, 10, 0);
		sliderPoison1.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				JSlider source = (JSlider)arg0.getSource();
			    if (source.getValueIsAdjusting()) {
			        lblPoison1.setText(""+(int)source.getValue());
			    }
			}
		});
		sliderPoison1.setMinorTickSpacing(1);
		sliderPoison1.setMajorTickSpacing(1);
		sliderPoison1.setOpaque(false);
		sliderPoison1.setBounds(70, 251, 175, 42);
		frame.getContentPane().add(sliderPoison1);		
		
		
		JSlider sliderPoison2 = new JSlider(JSlider.HORIZONTAL, 0, 10, 0);
		sliderPoison2.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent arg0) {
				JSlider source = (JSlider)arg0.getSource();
			    if (source.getValueIsAdjusting()) {
			        lblPoison2.setText(""+(int)source.getValue());
			    }
			}
		});
		sliderPoison2.setMinorTickSpacing(1);
		sliderPoison2.setMajorTickSpacing(1);
		sliderPoison2.setOpaque(false);
		sliderPoison2.setBounds(380, 251, 175, 42);
		frame.getContentPane().add(sliderPoison2);
		
		
		Icon iconPoison  = new ImageIcon(Main.class.getResource("/img/knob.gif"));
		sliderPoison1.setUI(new IconThumbSliderUI(iconPoison, iconPoison));
		sliderPoison2.setUI(new IconThumbSliderUI(iconPoison, iconPoison));
		
		
		JButton btnDice20 = new JButton("");
		btnDice20.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, (int)((Math.random() * 20) + 1));
			}
		});
		btnDice20.setIcon(new ImageIcon(Main.class.getResource("/img/d20.gif")));
		btnDice20.setOpaque(false);
		btnDice20.setContentAreaFilled(false);
		btnDice20.setBorderPainted(false);
		btnDice20.setFocusPainted(false);
		btnDice20.setBounds(257, 11, 50, 50);
		frame.getContentPane().add(btnDice20);
		
		
		JButton btnDice6 = new JButton("");
		btnDice6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, (int)((Math.random() * 6) + 1));
			}
		});
		btnDice6.setIcon(new ImageIcon(Main.class.getResource("/img/d6.gif")));
		btnDice6.setOpaque(false);
		btnDice6.setContentAreaFilled(false);
		btnDice6.setBorderPainted(false);
		btnDice6.setFocusPainted(false);
		btnDice6.setBounds(318, 11, 50, 50);
		frame.getContentPane().add(btnDice6);
		

		JButton btnReset = new JButton();
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				life1 = 20;
				life2 = 20;
				lblLife1.setText(""+life1);
				lblLife2.setText(""+life2);
				sliderPoison1.setValue(0);
				sliderPoison2.setValue(0);
				lblPoison1.setText(""+sliderPoison1.getValue());
				lblPoison2.setText(""+sliderPoison2.getValue());
				do {
					background1 = (int)((Math.random() * 5));
					background2 = (int)((Math.random() * 5));
				} while (background1 == background2);
				if (background1 == 0) {
					lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/plains.jpg")));
				}
				else if (background1 == 1) {
					lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/island.jpg")));
				}
				else if (background1 == 2) {
					lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/swamp.jpg")));
				}
				else if (background1 == 3) {
					lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/mountain.jpg")));
				}
				else {
					lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/forest.jpg")));
				}
				if (background2 == 0) {
					lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/plains.jpg")));
				}
				else if (background2 == 1) {
					lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/island.jpg")));
				}
				else if (background2 == 2) {
					lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/swamp.jpg")));
				}
				else if (background2 == 3) {
					lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/mountain.jpg")));
				}
				else {
					lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/forest.jpg")));
				}			
			}
		});
		btnReset.setIcon(new ImageIcon(Main.class.getResource("/img/mtg.gif")));
		btnReset.setOpaque(false);
		btnReset.setContentAreaFilled(false);
		btnReset.setBorderPainted(false);
		btnReset.setFocusPainted(false);
		btnReset.setBounds(288, 160, 50, 50);
		frame.getContentPane().add(btnReset);
		
		
		lblBackground1 = new JLabel();
		//lblBackground1.setIcon(new ImageIcon(Test2.class.getResource("/img/island.jpg")));
		if (background1 == 0) {
			lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/plains.jpg")));
		}
		else if (background1 == 1) {
			lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/island.jpg")));
		}
		else if (background1 == 2) {
			lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/swamp.jpg")));
		}
		else if (background1 == 3) {
			lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/mountain.jpg")));
		}
		else {
			lblBackground1.setIcon(new ImageIcon(Main.class.getResource("/img/forest.jpg")));
		}
		lblBackground1.setBounds(0, 0, 312, 321);
		frame.getContentPane().add(lblBackground1);
		
		
		lblBackground2 = new JLabel();
		//lblBackground2.setIcon(new ImageIcon(Test2.class.getResource("/img/mountain.jpg")));
		if (background2 == 0) {
			lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/plains.jpg")));
		}
		else if (background2 == 1) {
			lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/island.jpg")));
		}
		else if (background2 == 2) {
			lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/swamp.jpg")));
		}
		else if (background2 == 3) {
			lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/mountain.jpg")));
		}
		else {
			lblBackground2.setIcon(new ImageIcon(Main.class.getResource("/img/forest.jpg")));
		}	
		lblBackground2.setBounds(312, 0, 312, 321);
		frame.getContentPane().add(lblBackground2);
	}
}