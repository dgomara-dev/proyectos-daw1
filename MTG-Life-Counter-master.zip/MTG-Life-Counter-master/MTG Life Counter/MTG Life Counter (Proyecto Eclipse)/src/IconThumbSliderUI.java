import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import javax.swing.Icon;
import javax.swing.JSlider;
import javax.swing.plaf.metal.MetalSliderUI;

public class IconThumbSliderUI extends MetalSliderUI {
    private Icon hThumbIcon = null;
    private Icon vThumbIcon = null;
   
    public IconThumbSliderUI(Icon hThumbIcon, Icon vThumbIcon) {
        setHorizontalThumbIcon(hThumbIcon);
        setVerticalThumbIcon(vThumbIcon);
    }
   
    public void setHorizontalThumbIcon(Icon hThumbIcon) {
       if (hThumbIcon == null) {
    	   this.hThumbIcon = horizThumbIcon;
       }
       else {
    	   this.hThumbIcon = hThumbIcon;
       }
    }
  
    public void setVerticalThumbIcon(Icon vThumbIcon) {
       if (vThumbIcon == null) {
    	   this.vThumbIcon = vertThumbIcon;
       }
       else {
    	   this.vThumbIcon = vThumbIcon;
       }
    }
  
    public void paintThumb(Graphics g)  {
        Rectangle knobBounds = thumbRect;
        g.translate( knobBounds.x, knobBounds.y );
        if ( slider.getOrientation() == JSlider.HORIZONTAL ) {
            hThumbIcon.paintIcon( slider, g, 0, 0 );
        }
        else {
            vThumbIcon.paintIcon( slider, g, 0, 0 );
        }
        g.translate( -knobBounds.x, -knobBounds.y );
    }
  
    protected Dimension getThumbSize() {
        Dimension size = new Dimension();
        if (slider.getOrientation() == JSlider.VERTICAL ) {
	        size.width = vThumbIcon.getIconWidth();
	        size.height = vThumbIcon.getIconHeight();
        }
	    else {
	        size.width = hThumbIcon.getIconWidth();
	        size.height = vThumbIcon.getIconHeight();
	    }
        return size;
    }
}