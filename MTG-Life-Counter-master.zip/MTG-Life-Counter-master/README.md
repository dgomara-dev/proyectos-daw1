# MTG-Life-Counter
Aplicación en Java que funciona como contador de vidas para el juego de cartas "Magic: The Gathering". Permite llevar la cuenta de las vidas, contadores de veneno, lanzar D6 y D20, así como resetear los cambios (los fondos cambian aleatoriamente con cada reseteo). Muy simple todo, hecho con Swing.
