# Almas-Oscuras
Juego sencillo que hice en su día para aprender y practicar objetos y ventanas con Swing. Es la introducción del juego Dark Souls de forma narrada, con interacciones sencillas de "aceptar/cancelar". Dura menos de 2 minutos, no tiene mucho misterio.
