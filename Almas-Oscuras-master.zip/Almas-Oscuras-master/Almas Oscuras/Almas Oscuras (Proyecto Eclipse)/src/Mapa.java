import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Mapa {
	
	// INTRODUCCI�N
	public void intro(Jugador jugador) {
		
		String nombre = null;
		boolean repeat = true;
		
		Principal.boton1.setVisible(false);
		Principal.boton2.setVisible(false);
		Principal.textField.setVisible(false);
		Principal.etiqueta.setVisible(false);
		Principal.boton1.setText("INICIAR");
		
		Principal.textPane.setText("\n\n\n\t\t\t\t ALMAS OSCURAS"
				+ "\n\n\t\t\t\t       @2017");
		jugador.esperarAceptar(jugador);
		do {
			repeat = false;
			Principal.boton1.setText("SIGUIENTE");
			Principal.textPane.setText("\n\n\n\t\t\tCrear personaje, introducir nombre:");
			Principal.textField.setVisible(true);
			Principal.etiqueta.setVisible(true);		
			jugador.esperarAceptar(jugador);
			nombre = Principal.textField.getText();
			if (nombre.length() < 1) {
				JOptionPane.showMessageDialog(null, "Introduce tu nombre.");
				repeat = true;
			}
			else if (nombre.length() > 10){
				JOptionPane.showMessageDialog(null, "Nombre demasiado largo.");
				Principal.textField.setText("");
				repeat = true;
			}
		} while(repeat == true);
		jugador.setNombre(nombre);
		Principal.textField.setText("");
		Principal.textField.setVisible(false);
		Principal.etiqueta.setVisible(false);
		Principal.textPane.setText("\n\n\n\n\n\t\t\t\t\t...");
		jugador.pausa(3000);
		Principal.textPane.setText("\n\n\n\tEn la Edad Antigua, el mundo era amorfo y estaba envuelto en niebla. Una"
				+ "\n\ttierra de riscos grises, �rboles gigantescos y dragones eternos."
				+ "\n\n\tPero entonces lleg� el Fuego. Y con el Fuego, llego la Disparidad."
				+ "\n\n\tCalor y fr�o, vida y muerte, y por supuesto... Luz y Oscuridad.");
		jugador.esperarAceptar(jugador);
		Principal.textPane.setText("\n\tEntonces, ellos surgieron de la oscuridad. Y encontraron las almas de los"
				+ "\n\tdioses dentro de la llama."
				+ "\n\n\tNito, el primero de los muertos."
				+ "\n\n\tLa bruja de Izalith y sus hijas del caos."
				+ "\n\n\tGwyn, el Se�or de la Luz Solar, y sus leales caballeros."
				+ "\n\n\tY el furtivo pigmeo, a menudo olvidado.");
		jugador.esperarAceptar(jugador);
		Principal.textPane.setText("\n\n\tCon la fuerza de los dioses, desafiaron a los dragones. Gwyn y sus poderosos"
				+ "\n\trayos despejaron sus escamas p�treas, las brujas tejieron tormentas de fuego,"
				+ "\n\tNito provoc� un miasma de muerte y enfermedad."
				+ "\n\tY Seath el desacamado traicion� a los suyos y los dragones desaparecieron."
				+ "\n\n\tAs� comenz� la Edad del Fuego..."
				+ "\n\n\tPronto las llamas se apagaron y s�lo qued� Oscuridad.");
		jugador.esperarAceptar(jugador);
		Principal.textPane.setText("\n\n\tAhora solo quedan ascuas, y el hombre ya no ve el sol; tan solo noches"
				+ "\n\teternas. Entre los vivos pueden verse a los que sufren la maldici�n de la"
				+ "\n\tSe�al Oscura."
				+ "\n\n\tAs� es. La Se�al Oscura de los no muertos."
				+ "\n\n\tEn esta tierra, han reunido a todos los no muertos para llevarlos al norte."
				+ "\n\tAll� los encerrar�n hasta que llegue el fin del mundo.");
		jugador.esperarAceptar(jugador);
		Principal.textPane.setText("\n\n\n\n\n\t\t\t\tEse es tu destino...");
		jugador.pausa(3000);
		Principal.textPane.setText("\n\n\n\n\n\t\t\t\t\t...");
		jugador.pausa(3000);
	}
		
	
	
	//CELDA INICIAL
	public void celda(Jugador jugador, Objetos llave) {

		boolean repeat;
		
		Principal.boton1.setVisible(false);
		Principal.boton2.setVisible(false);
		Principal.textField.setVisible(false);
		Principal.etiqueta.setVisible(false);
		Principal.boton1.setText("SIGUIENTE");		
		
		Principal.fondo.setIcon(new ImageIcon(Principal.class.getResource("/img/backgroundRefugio.jpg")));
		Principal.textPane.setText("\n\n\n\n\n\t\t\t   REFUGIO DE LOS NO MUERTOS");
		jugador.pausa(5000);	
		Principal.textPane.setText("\n    LUGAR: Celda"
				+ "\n\n\tTe encuentras en un lugar oscuro y h�medo. La �nica luz del habit�culo"
				+ "\n\tentra por un agujero en el techo."
				+ "\n\n\tSe oye el musitar de ratas a lo lejos.");
		jugador.esperarAceptar(jugador);
		Principal.textPane.setText("\n    LUGAR: Celda"
				+"\n\n\tRompiendo el silencio, un cuerpo cae por el agujero justo a tus pies."
				+ "\n\n\tMiras hacia arriba y ves un hombre vestido de armadura de caballero. Te"
				+ "\n\tmira y desaparece en el tejado."
				+ "\n\n\tDebe de ser �l quien ha arrojado el cad�ver a tu celda.");
		jugador.esperarAceptar(jugador);	
		Principal.textPane.setText("\n    LUGAR: Celda"
				+"\n\n\tEl cuerpo pertenece a un hueco, uno de los muchos no muertos que perdieron"
				+ "\n\tsu humanidad y con ella, la cordura. El refugio est� repleto de ellos."
				+ "\n\n\tParece que tiene algo aferrado en las manos. Mejor no acercarse demasiado,"
				+ "\n\tlos huecos son peligrosos y puede que este a�n siga vivo..."
				+ "\n\n\t�Quieres registrar el cad�ver?");
		Principal.boton1.setText("ACEPTAR");
		jugador.esperarRespuesta(jugador);
		Principal.boton1.setText("SIGUIENTE");
		if (jugador.getRespuesta() == true) {
			jugador.saveObj(llave);
		}
		else if (jugador.getRespuesta() == false) {
			Principal.textPane.setText("\n\n\n\n\n\t\t\t     Dejas el cad�ver donde est�.");
			jugador.pausa(3000);
		}
		do {
			repeat=false;
			Principal.textPane.setText("\n    LUGAR: Celda"
					+"\n\n\tEl caballero con armadura ha despertado tu curiosidad. Te acercas a la puerta"
					+ "\n\tde la celda y la examinas con detenimiento."
					+ "\n\n\tEst� hecha de barrotes de hierro corro�dos por el �xido, pero tan s�lidos"
					+ "\n\tcomo en sus mejores d�as."
					+ "\n\n\t�Quieres abrir la puerta?");
			Principal.boton1.setText("ACEPTAR");
			jugador.esperarRespuesta(jugador);
			Principal.boton1.setText("SIGUIENTE");
				if (jugador.getRespuesta() == true) {
					if (llave.getEstado() == true) {
						Principal.textPane.setText("\n\n\n\n\n\t\t\tUsas la llave y la puerta se ha abierto.");
						jugador.pausa(3000);
						jugador.deleteObj(llave);
					}
					else if (llave.getEstado() == false) {
						do {
							repeat = false;
							Principal.textPane.setText("\n    LUGAR: Celda"
									+ "\n\n\n\tLa puerta est� cerrada a cal y canto, necesitas una llave. Quiz�s haya"
									+ "\n\talgo que te ayude en el cuerpo que ha tirado el caballero..."
									+ "\n\n\t�Vas a registrar el cad�ver?");
							Principal.boton1.setText("ACEPTAR");
							jugador.esperarRespuesta(jugador);
							if (jugador.getRespuesta() == true) {
								jugador.saveObj(llave);
							}
							else if (jugador.getRespuesta() == false) {
								JOptionPane.showMessageDialog(null, "�No te rindas! �Esqueleto!");
								repeat = true;
							}	
						} while(repeat == true);
						repeat = true;
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "�No te rindas! �Esqueleto!");
					repeat = true;	
				}		
		} while(repeat == true);
		Principal.boton1.setVisible(false);
		JOptionPane.showMessageDialog(null, "Has logrado escapar de tu celda."
				+ "\nEs hora de buscar al caballero y obtener respuestas.");
	}
	
	
	
	public void fin() {
		Principal.boton1.setVisible(false);
		Principal.boton2.setVisible(false);
		Principal.textField.setVisible(false);
		Principal.etiqueta.setVisible(false);
		Principal.fondo.setIcon(new ImageIcon(Principal.class.getResource("/img/backgroundIntro.jpg")));
		Principal.textPane.setText("\n\n\n\n\n\t\t\t\t          FIN");
		try {
			Thread.sleep(5000);
		}
		catch(InterruptedException e) {
		}
		System.exit(0);
	}
}
