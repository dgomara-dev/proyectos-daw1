public class Jugador {
	
	private String nombre;
	private boolean respuesta;
	private boolean pulsacion = false;
		

	// Introducir nombre
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	// Obtener nombre
	public String getNombre() {
		return nombre;
	}
	
	
	// Guardar objeto en bolsa
	public void saveObj(Objetos objeto) {
		Principal.boton1.setVisible(false);
		objeto.setEstado(true);
		Principal.textPane.setText("\n\n\n\n\n\t\t\t     "+objeto.getNombre()+" a�adido al inventario.");
		try {
			Thread.sleep(3000);
		}
		catch(InterruptedException e) {
		}
		Principal.boton1.setVisible(true);
	}
	
	
	// Eliminar objeto en bolsa
	public void deleteObj(Objetos objeto) {
		Principal.boton1.setVisible(false);
		objeto.setEstado(false);
		Principal.textPane.setText("\n\n\n\n\n\t\t\t     "+objeto.getNombre()+" eliminado del inventario.");
		try {
			Thread.sleep(3000);
		}
		catch(InterruptedException e) {
		}
		Principal.boton1.setVisible(true);
	}
	
	
	// Introducir respuesta (SI/NO)
	public void setRespuesta(boolean respuesta) {
		this.respuesta = respuesta;
	}
	
	
	// Obtener respuesta (SI/NO)
	public boolean getRespuesta() {
		return respuesta;
	}
	
	
	// Poner la posici�n de la pulsaci�n
	public void setPulsacion(boolean pulsacion) {
		this.pulsacion = pulsacion;
	}
	
	
	// Pedir que se pulse un bot�n
	public boolean getPulsacion() {
		return pulsacion;
	}
	
	
	// Esperar a que el jugador pulse el bot�n Aceptar
	public void esperarAceptar(Jugador jugador) {
		Principal.boton1.setVisible(true);
		jugador.setRespuesta(false);
		do {
			try {
				Thread.sleep(1);
			}
			catch(InterruptedException e) {
			}
		} while(jugador.getRespuesta() == false);
		Principal.textPane.setText("");
		try {
			Thread.sleep(100);
		}
		catch(InterruptedException e) {
		}
		Principal.boton2.setVisible(false);
	}
	
	
	// Esperar a que el jugador pulse cualquier bot�n
	public void esperarRespuesta(Jugador jugador) {
		Principal.boton1.setVisible(true);
		Principal.boton2.setVisible(true);
		jugador.setPulsacion(false);
		do {
			try {
				Thread.sleep(1);
			}
			catch(InterruptedException e) {
			}
		} while(jugador.getPulsacion() == false);
		Principal.textPane.setText("");
		try {
			Thread.sleep(50);
		}
		catch(InterruptedException e) {
		}
		Principal.boton1.setVisible(false);
		Principal.boton2.setVisible(false);
	}
	
	
	// Inhabilitar al jugador durante X segundos.
	public void pausa(int tiempo) {
		Principal.boton1.setVisible(false);
		try {
			Thread.sleep(tiempo);
		}
		catch(InterruptedException e) {
		}
		Principal.boton1.setVisible(true);
	}
}
