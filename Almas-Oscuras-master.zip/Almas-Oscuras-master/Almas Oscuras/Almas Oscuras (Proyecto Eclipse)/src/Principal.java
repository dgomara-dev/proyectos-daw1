import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class Principal {
	
	public static JButton boton1 = new JButton("ACEPTAR");
	public static JButton boton2 = new JButton("CANCELAR");
	public static JTextField textField = new JTextField();
	public static JTextPane textPane = new JTextPane();
	public static JLabel etiqueta = new JLabel("Habla aqu�:");
	public static JLabel fondo = new JLabel("Fondo");	
	
	
	
	
	public static void main(String args[]) {
		
		// OBJETOS CLAVE
		Jugador jugador = new Jugador();		// Para llamar funciones de su clase (atributos, inventario, etc.)
		Mapa mapa = new Mapa(); 				// S�lo sirve para llamar a las estancias.
		Objetos llave = new Objetos("'Llave'");	// Objeto de inventario
		
		
		
		// SWING
		// Ventana
		JFrame ventana = new JFrame("Almas Oscuras");
		ventana.setResizable(false);
		ventana.setIconImage(Toolkit.getDefaultToolkit().getImage(Principal.class.getResource("/img/icon.png")));
		ventana.getContentPane().setForeground(new Color(255, 255, 255));
		ventana.setBounds(150,150,960,540);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.getContentPane().setLayout(null);
				
		
		// Panel
		JPanel panel = (JPanel) ventana.getContentPane();
		panel.setLayout(null);
				
				
		// Botones
		boton1.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
		    	jugador.setRespuesta(true);
				jugador.setPulsacion(true);
		    }
		});
		boton1.setBackground(Color.DARK_GRAY);
		boton1.setForeground(Color.WHITE);
		boton1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		boton1.setBounds(371,375,200,75);
		panel.add(boton1);
				
		boton2.addActionListener(new ActionListener(){
		    public void actionPerformed(ActionEvent e){
		    	jugador.setRespuesta(false);
				jugador.setPulsacion(true);
		    }
		});
		boton2.setBackground(Color.DARK_GRAY);
		boton2.setForeground(Color.WHITE);
		boton2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		boton2.setBounds(640,375,200,75);
		panel.add(boton2);
				
				
		// Caja para introducir texto
		textField.setFont(new Font("Tahoma", Font.PLAIN, 13));
		textField.setBounds(100,398,200,30);
		ventana.getContentPane().add(textField);
		textField.setColumns(10);
		
				
		// Caja para mostrar texto
		textPane.setText( "original text" );
		textPane.setForeground(new Color(255, 255, 255));
		textPane.setFont(new Font("Tahoma", Font.PLAIN, 18));
		textPane.setEditable(false);
		textPane.setBackground(new Color(105, 105, 105));
		textPane.setBounds(100, 53, 740, 275);
		ventana.getContentPane().add(textPane);
				
				
		// Etiqueta de la caja de texto
		etiqueta.setForeground(Color.WHITE);
		etiqueta.setFont(new Font("Tahoma", Font.ITALIC, 15));
		etiqueta.setBounds(161, 375, 77, 19);
		ventana.getContentPane().add(etiqueta);
		
			
		// Fondo
		fondo.setIcon(new ImageIcon(Principal.class.getResource("/img/backgroundIntro.jpg")));
		fondo.setLabelFor(fondo);
		fondo.setBounds(0, 0, 960, 511);
		ventana.getContentPane().add(fondo);
		
		ventana.setVisible(true);
						
		
		//DESARROLLO
		mapa.intro(jugador);
		mapa.celda(jugador, llave);
		mapa.fin();
	}
}