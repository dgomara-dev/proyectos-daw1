public class Objetos {
	
	private String nombre;
	private boolean estado;
	
	
	// Constructor
	public Objetos(String nombre) {
		this.nombre = nombre;
		estado = false;
	}
	
	
	// Obtener nombre
	public String getNombre() {
		return nombre;
	}
	
	
	// Introducir el estado
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	

	// Obtener estado
	public boolean getEstado() {
		return estado;
	}
}