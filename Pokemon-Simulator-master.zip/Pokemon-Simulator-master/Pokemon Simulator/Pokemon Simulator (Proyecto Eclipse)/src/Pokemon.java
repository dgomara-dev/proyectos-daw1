import javax.swing.JLabel;
import javax.swing.JProgressBar;

public class Pokemon {
	
	private String nombre;
	private int nivel;
	private int saludMax;
	private int salud;
	private int ataque;
	private int defensa;
	private int velocidad;
	
	private JProgressBar barraSalud;
	private JLabel lblSalud;
	private JLabel img;
	
	public Pokemon(String nombre, int nivel, int saludMax, int ataque, int defensa, int velocidad) {
		this.nombre = nombre;
		this.nivel = nivel;
		this.saludMax = saludMax;
		salud = saludMax;
		this.ataque = ataque;
		this.defensa = defensa;
		this.velocidad = velocidad;
	}
		
	public String getNombre() {
		return nombre;
	}
		
	public int getNivel() {
		return nivel;
	}
		
	public int getSaludMax() {
		return saludMax;
	}
	
	public int getSalud() {
		return salud;
	}
		
	public int getAtaque() {
		return ataque;
	}
		
	public int getDefensa() {
		return defensa;
	}
		
	public int getVelocidad() {
		return velocidad;
	}
		
	public JProgressBar getBarraSalud() {
		return barraSalud;
	}
		
	public JLabel getLblSalud() {
		return lblSalud;
	}
		
	public JLabel getImg() {
		return img;
	}
		
	public void setSalud(int salud) {
		this.salud = salud;
	}
		
	public void setBarraSalud(JProgressBar barraSalud) {
		this.barraSalud = barraSalud;
	}
		
	public void setLblSalud(JLabel lblSalud) {
		this.lblSalud = lblSalud;
	}
		
	public void setImg(JLabel img) {
		this.img = img;
	}
}
