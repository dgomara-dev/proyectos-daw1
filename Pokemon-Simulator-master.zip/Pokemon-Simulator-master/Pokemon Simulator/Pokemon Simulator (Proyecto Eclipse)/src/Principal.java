import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.ImageIcon;


public class Principal {

	private JFrame frame;
	private JLabel lblName1;
	private JLabel lblName2;
	private JLabel lblLvl1;
	private JLabel lblLvl2;
	private JLabel lblHealth1;
	private JLabel lblHealth2;
	private JLabel imgFighter1;
	private JLabel imgFighter2;
	private JProgressBar healthBar1;
	private JProgressBar healthBar2;
	private TextPanel textPanel;

	private static Principal principal = new Principal();
	public static boolean next = false;
	
	
	
	public static void main(String[] args) throws InterruptedException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//Window window = new Window();
					principal.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		principal.script();
	}


	
	public Principal() {
		initialize();
	}


	
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		lblName1 = new JLabel("Name 1");
		lblName1.setBounds(20, 11, 220, 30);
		lblName1.setFont(new Font("Consolas", Font.PLAIN, 32));
		frame.getContentPane().add(lblName1);
		
		lblName2 = new JLabel("Name 2");
		lblName2.setBounds(274, 236, 220, 30);
		lblName2.setFont(new Font("Consolas", Font.PLAIN, 32));
		frame.getContentPane().add(lblName2);
		
		lblLvl1 = new JLabel(":Nvl 0");
		lblLvl1.setBounds(20, 52, 220, 30);
		lblLvl1.setFont(new Font("Consolas", Font.BOLD, 32));
		frame.getContentPane().add(lblLvl1);
		
		lblLvl2 = new JLabel(":Nvl 0");
		lblLvl2.setBounds(274, 277, 220, 30);
		lblLvl2.setFont(new Font("Consolas", Font.BOLD, 32));
		frame.getContentPane().add(lblLvl2);
		
		lblHealth1 = new JLabel("0");
		lblHealth1.setBounds(98, 129, 200, 30);
		lblHealth1.setFont(new Font("Consolas", Font.BOLD, 32));
		frame.getContentPane().add(lblHealth1);
		
		lblHealth2 = new JLabel("0");
		lblHealth2.setBounds(354, 354, 200, 30);
		lblHealth2.setFont(new Font("Consolas", Font.BOLD, 32));
		frame.getContentPane().add(lblHealth2);
		
		imgFighter1 = new JLabel("img");
		imgFighter1.setBounds(62, 239, 150, 150);
		imgFighter1.setIcon(new ImageIcon(Principal.class.getResource("/img/charmander.png")));
		frame.getContentPane().add(imgFighter1);
		
		imgFighter2 = new JLabel("img");
		imgFighter2.setBounds(377, 47, 150, 150);
		imgFighter2.setIcon(new ImageIcon(Principal.class.getResource("/img/pikachu.png")));
		frame.getContentPane().add(imgFighter2);
		
		healthBar1 = new JProgressBar();
		healthBar1.setBounds(20, 93, 300, 25);
		healthBar1.setMaximum(10000);
		healthBar1.setForeground(Color.GREEN);
		frame.getContentPane().add(healthBar1);
		
		healthBar2 = new JProgressBar();
		healthBar2.setBounds(274, 318, 300, 25);
		healthBar2.setMaximum(10000);
		healthBar2.setForeground(Color.GREEN);
		frame.getContentPane().add(healthBar2);
		
		textPanel = new TextPanel();
		frame.getContentPane().add(textPanel);
			
	}
	
	
	
	public void script() throws InterruptedException {
		
		Pokemon pkmn1 = new Pokemon("PIKACHU", 10, 35, 53, 45, 90);
		Pokemon pkmn2 = new Pokemon("CHARMANDER", 5, 39, 56, 47, 65);
		Pokemon primero;
		Pokemon segundo;
		final int PS1 = pkmn1.getSalud();
		final int PS2 = pkmn2.getSalud();
		int potenciaMovimiento = 50;
		
		pkmn1.setBarraSalud(healthBar1);
		pkmn1.setLblSalud(lblHealth1);
		pkmn1.setImg(imgFighter1);
		pkmn2.setBarraSalud(healthBar2);
		pkmn2.setLblSalud(lblHealth2);
		pkmn2.setImg(imgFighter2);
		
		lblName1.setText(pkmn1.getNombre());
		lblName2.setText(pkmn2.getNombre());
		lblLvl1.setText(":Nvl "+pkmn1.getNivel());
		lblLvl2.setText(":Nvl "+pkmn2.getNivel());
		lblHealth1.setText(pkmn1.getSalud()+" / "+pkmn1.getSalud());
		lblHealth2.setText(pkmn2.getSalud()+" / "+pkmn2.getSalud());
	
		healthBar1.setValue(10000);
		healthBar2.setValue(10000);
		
		textPanel.getTextArea().setText("�Un "+pkmn1.getNombre()+" salvaje apareci�!");
		Thread.sleep(1000);
		
		
		
		// Comienzo del blucle del combate
		do {
			
			// Asignar los peleles seg�n la velocidad del Pok�mon
			if (pkmn1.getVelocidad() > pkmn2.getVelocidad()) {
				primero = pkmn1;
				segundo = pkmn2;	
			}
			else if (pkmn1.getVelocidad() < pkmn2.getVelocidad()) {
				primero = pkmn2;
				segundo = pkmn1;
			}
			else {
				int random = (int)(Math.random()+1*2);
				if (random == 1) {
					primero = pkmn1;
					segundo = pkmn2;
				}
				else {
					primero = pkmn2;
					segundo = pkmn1;
				}
			}
			
			// Comienzo del primer turno
			principal.battle1(primero, segundo, PS1, PS2, potenciaMovimiento);
			
			// Comienzo del segundo turno	
			principal.battle2(segundo, primero, PS2, PS1, potenciaMovimiento);
				
		} while(pkmn1.getSalud()>0 && pkmn2.getSalud()>0);
		
		
		
		
		if (pkmn1.getSalud() > 1) {
			textPanel.getTextArea().setText("�"+pkmn2.getNombre()+" se debilit�!\n");
			textPanel.getTextArea().append("�"+pkmn1.getNombre()+" gan� el combate!");
			for (int i=0; i<=150; i++) {
				Thread.sleep(1);
				imgFighter1.setBounds(62, 239+i, 150, 150-i);
			}
		}
		else {
			textPanel.getTextArea().setText("�"+pkmn1.getNombre()+" se debilit�!\n");
			textPanel.getTextArea().append("�"+pkmn2.getNombre()+" gan� el combate!");
			for (int i=0; i<=150; i++) {
				Thread.sleep(1);
				imgFighter2.setBounds(377, 47+i, 150, 150-i);
			}
		}
		
		Thread.sleep(2000);
		System.exit(0);
	}
	
	
	
	public void battle1(Pokemon primero, Pokemon segundo, int HP1, int HP2, int movePower) throws InterruptedException {
		
		if (segundo.getSalud() > 0 && primero.getSalud() > 0) {
			textPanel.getTextArea().setText("�Qu� deber�a hacer "+segundo.getNombre()+"?");
			do {
				Thread.sleep(10);
			}while (next == false);
		}		
		if (segundo.getSalud() > 0) {
			for (int i=0; i<100; i++) {
				Thread.sleep(1);
				primero.getImg().setBounds(primero.getImg().getX()+1, primero.getImg().getY(), 150, 150);
			}
			for (int i=0; i<100; i++) {
				Thread.sleep(1);
				primero.getImg().setBounds(primero.getImg().getX()-1, primero.getImg().getY(), 150, 150);
			}
			// C�lculo de da�o
			int damage = ((((2*segundo.getNivel())/5)+2)*movePower*(segundo.getAtaque()/primero.getDefensa())/50)+2;
			primero.setSalud((int)(primero.getSalud()-damage));
			
			// Cambiar la etiqueta que muestra el da�o num�rico
			if (primero.getSalud() < 0) {
				primero.getLblSalud().setText("0 / "+primero.getSaludMax());
			}
			else {
				primero.getLblSalud().setText(primero.getSalud()+" / "+primero.getSaludMax());
			}
			
			// Cambiar la barra de progreso
			for (int i=0; i<damage; i++) {
				Thread.sleep(50);
				primero.getBarraSalud().setValue(primero.getBarraSalud().getValue()-(10000/HP1));
			}
			
			// Cambiar color barra de progreso
			if (primero.getSalud()<(HP1*2/3) && primero.getSalud()>=(HP1/3)) {
				primero.getBarraSalud().setForeground(Color.ORANGE);
			}
			else if (primero.getSalud()<(HP1/3)) {
				primero.getBarraSalud().setForeground(Color.RED);
			}
			
			// Finalizar turno
			textPanel.getTextArea().setText("�"+segundo.getNombre()+" hizo "+(int)damage+" puntos de da�o!\n");
			Thread.sleep(1000);
		}
	}
	
	
	
	public void battle2(Pokemon dummy1, Pokemon dummy2, int HP1, int HP2, int movePower) throws InterruptedException {
		
		if (dummy2.getSalud() > 0) {
			for (int i=0; i<100; i++) {
				Thread.sleep(1);
				dummy1.getImg().setBounds(dummy1.getImg().getX()-1, dummy1.getImg().getY(), 150, 150);
			}
			for (int i=0; i<100; i++) {
				Thread.sleep(1);
				dummy1.getImg().setBounds(dummy1.getImg().getX()+1, dummy1.getImg().getY(), 150, 150);
			}
			// C�lculo de da�o
			int damage = ((((2*dummy2.getNivel())/5)+2)*movePower*(dummy2.getAtaque()/dummy1.getDefensa())/50)+2;
			dummy1.setSalud((int)(dummy1.getSalud()-damage));
			
			// Cambiar la etiqueta que muestra el da�o num�rico
			if (dummy1.getSalud() < 0) {
				dummy1.getLblSalud().setText("0 / "+dummy1.getSaludMax());
			}
			else {
				dummy1.getLblSalud().setText(dummy1.getSalud()+" / "+dummy1.getSaludMax());
			}
			
			// Cambiar la barra de progreso
			for (int i=0; i<damage; i++) {
				Thread.sleep(50);
				dummy1.getBarraSalud().setValue(dummy1.getBarraSalud().getValue()-(10000/HP1));
			}
			
			// Cambiar color barra de progreso
			if (dummy1.getSalud()<(HP1*2/3) && dummy1.getSalud()>=(HP1/3)) {
				dummy1.getBarraSalud().setForeground(Color.ORANGE);
			}
			else if (dummy1.getSalud()<(HP1/3)) {
				dummy1.getBarraSalud().setForeground(Color.RED);
			}
			
			// Finalizar turno
			textPanel.getTextArea().setText("�"+dummy2.getNombre()+" hizo "+(int)damage+" puntos de da�o!\n");
			Thread.sleep(1000);
		}
	}
}
