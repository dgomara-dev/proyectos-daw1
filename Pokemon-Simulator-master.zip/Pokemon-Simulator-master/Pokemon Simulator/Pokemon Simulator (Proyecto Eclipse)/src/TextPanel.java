import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;

@SuppressWarnings("serial")
public class TextPanel extends JPanel {
	
	private JTextArea textArea;
	private JButton btnNext;
	
	
	public TextPanel() {
		setBounds(12, 400, 562, 150);
		setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		setBackground(Color.WHITE);
		setLayout(null);
		
		textArea = new JTextArea();
		textArea.setBounds(10, 11, 406, 128);
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 21));
		textArea.setBackground(Color.WHITE);
		textArea.setEditable(false);
		add(textArea);
		
		btnNext = new JButton("�LUCHA!");
		btnNext.setFont(new Font("Tahoma", Font.PLAIN, 21));
		btnNext.setBounds(424, 11, 128, 128);
		
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Principal.next = true;
				try { Thread.sleep(10); } catch (InterruptedException e) {}
				Principal.next = false;
			}
		});
		add(btnNext);
	}
	
	
	public JTextArea getTextArea() {
		return textArea;
	}
	
}
