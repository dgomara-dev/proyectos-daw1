# Otra-aventura-conversacional
Otra aventura conversacional en Java, para variar. Esta vez con una mejor estructura de código y con interfaz gráfica, pero que a cambio deja menos libertad creativa por las limitaciones que esto impone.
