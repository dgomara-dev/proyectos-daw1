import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;

public class Principal {
	
	private JFrame frame;
	private JTextArea textArea;
	private JTextField textField;
	
	private Sala salaActual;
	private Sala s1;
	private Sala s2;
	private Sala s3;
	private Sala s4;
	private Item i1;
	private Item i2;
	
	private boolean juegoEmpezado;

	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public Principal() {
		
		initialize();
		
		s1 = new Sala("Sala principal", "Est�s en una sala tenuemente iluminada por una antorcha.\n Hay dos salidas, una al NORTE y otra al OESTE.");
		s2 = new Sala("Celda", "Te encuentras en una peque�a celda llena de huesos.\n Una �nica calavera est� tirada en un rinc�n.\n Hay una salida direcci�n NORTE y otra direcci�n ESTE.");
		s3 = new Sala("Altar", "Un altar de piedra ocupa el centro de la sala.\n Se puede salir por el SUR o por el OESTE.");
		s4 = new Sala("Alcantarillado", "Desde una rejilla en el techo entra luz del exterior.\n Las salidas est�n al SUR y al ESTE.");
		
		i1 = new Item("Calavera", "Le falta la mand�bula.");
		i2 = new Item("Llave", "Tu llave hacia la libertad.");
		
		s1.addDescripcion("antorcha", "Cuidado, que quema.");
		s2.addDescripcion("huesos", "Parece que llevan aqu� mucho tiempo.");
		s2.addDescripcion("calavera", "Le falta la mand�bula.");
		s3.addDescripcion("altar", "Hay una hendidura en su superficie, algo podr�a encajar.");
		s3.addDescripcion("hendidura", "Es redonda, como si lo que encajara lo fuera tambi�n.");
		s4.addDescripcion("rejilla", "Est� cerrada bajo llave.");
		
		s2.setItem(i1);
		s3.setItem(i2);
		
		s1.addSalida(new Salida(Salida.NORTE, s3));
		s1.addSalida(new Salida(Salida.OESTE, s2));
		s2.addSalida(new Salida(Salida.NORTE, s4));
		s2.addSalida(new Salida(Salida.ESTE, s1));
		s3.addSalida(new Salida(Salida.SUR, s1));
		s3.addSalida(new Salida(Salida.OESTE, s4));
		s4.addSalida(new Salida(Salida.ESTE, s3));
		s4.addSalida(new Salida(Salida.SUR, s2));
		
		juegoEmpezado = false;
		
		salaActual = s1;
		
		textArea.setText("\n \"ESCAPE DE LA MAZMORRA\"\n Una aventura conversacional por Daniel G�mara (mayo 2018)");
		textArea.append("\n\n\n >> Introduce \"ayuda\" si es tu primera vez jugando.");	
	}


	public void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		frame.setBounds(300, 100, 640, 462);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 13, 612, 372);
		frame.getContentPane().add(scrollPane);
		
		textArea = new JTextArea("");
		textArea.setForeground(Color.GREEN);
		textArea.setFont(new Font("Consolas", Font.PLAIN, 16));
		textArea.setBackground(Color.BLACK);
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		
		JLabel lblNewLabel = new JLabel(">");
		lblNewLabel.setForeground(Color.GREEN);
		lblNewLabel.setFont(new Font("Consolas", Font.BOLD, 16));
		lblNewLabel.setBounds(160, 396, 9, 24);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField(" Pulsa ENTER aqu� para empezar");
		textField.setFont(new Font("Consolas", Font.PLAIN, 14));
		textField.setBackground(Color.LIGHT_GRAY);
		textField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (juegoEmpezado == false) {
					comportamientoTextField1();
				}
				else {
					comportamientoTextField2();
				}
			}
		});
		textField.setBounds(179, 398, 255, 22);
		frame.getContentPane().add(textField);
		textField.setColumns(10);	
	}

	
	
	private void mostrarSala() {
		textArea.append("\n - "+salaActual.getNombre()+"\n");
		textArea.append(" "+salaActual.getDescripcion()+"\n");	
	}
	
	
	
	private void comportamientoTextField1() {
		textArea.setText("");
		textField.setText("");
		mostrarSala();
		juegoEmpezado = true;
	}
	
	
	
	private void comportamientoTextField2() {
		if (i2.getUsado() == true) {
			System.exit(0);
		}
		try {
			String comando = textField.getText().trim().substring(0, textField.getText().indexOf(" "));
			String atributo = textField.getText().trim().substring(textField.getText().indexOf(" ")+1, textField.getText().length());
			if (comando.equalsIgnoreCase("ir")) {
				comandoIr(atributo);
			}
			else if (comando.equalsIgnoreCase("examinar")) {
				comandoExaminar(atributo);
			}
			else if (comando.equalsIgnoreCase("coger")) {
				comandoCoger(atributo);
			}
			else if (comando.equalsIgnoreCase("usar")) {
				comandoUsar(atributo);
			}
			else {
				textArea.append("\n Comando inv�lido.\n");
			}
		}catch (StringIndexOutOfBoundsException ex) {
			if (textField.getText().equalsIgnoreCase("ayuda")) {
				comandoAyuda();
			} 
			else {
				textArea.append("\n Comando mal introducido.\n");
			}
		}
		textField.setText("");
	}
	
	
	
	public void comandoIr(String atributo) {
		boolean acierto = false;
		for (Object obj: salaActual.getListaSalidas()) {
			Salida salida = (Salida)obj;
			if (salida.getNombreDireccion().equalsIgnoreCase(atributo)) {
				salaActual = salida.getLlevaA();
				mostrarSala();
				acierto = true;	
			}
		}
		if (acierto == false) {
			boolean nombreigual = false;
			Salida salida = new Salida();
			String[] vector = salida.getNombreDireccionVector();
			for (int i=0; i<vector.length && nombreigual == false; i++) {
				if (vector[i].equalsIgnoreCase(atributo)) {
					nombreigual = true;
				}
			}
			if (nombreigual == true) {
				textArea.append("\n Por ah� no hay salida.\n");
			}
			else {
				textArea.append("\n Esa direcci�n no existe.\n");
			}	
		}	
	}
	
	
	
	public void comandoExaminar(String atributo) {
		if (atributo.equalsIgnoreCase("sala")) {
			textArea.append("\n "+salaActual.getDescripcion()+"\n");
		}
		else {
			String linea = salaActual.getDiccionarioDescripciones().get(atributo.toLowerCase());
			if (linea == null) {
				textArea.append("\n No s� si eso se puede examinar...\n");
			}
			else {
				textArea.append("\n "+linea+"\n");
			}
		}
	}
		
	
	
	public void comandoCoger(String atributo) {
		if (salaActual.getNombre().equals("Celda") && i1.getRecogido() == false && atributo.equalsIgnoreCase(i1.getNombre())) {
			i1.setRecogido(true);
			textArea.append("\n Has cogido la calavera.\n");
			s2.setDescripcion(" Te encuentras en una peque�a celda llena de huesos.\n Hay una salida direcci�n NORTE y otra direcci�n ESTE.");
		}
		else if (salaActual.getNombre().equals("Altar") && i1.getUsado() == true && atributo.equalsIgnoreCase(i2.getNombre())) {
			i2.setRecogido(true);
			textArea.append("\n Has cogido la llave.\n");
			s2.setDescripcion(" Un altar de piedra ocupa el centro de la sala.\n Se puede salir por el SUR o por el OESTE.");
		}
		else {
			textArea.append("\n No s� si eso se puede coger... \n");
		}
	}
	
	
	
	public void comandoUsar(String atributo) {
		if (salaActual.getNombre().equals(s3.getNombre()) && i1.getRecogido() == true && i1.getUsado() == false && atributo.equalsIgnoreCase(i1.getNombre())) {
			i1.setUsado(true);
			textArea.append("\n Has usado la calavera.\n U.\n");
			s3.addDescripcion("cofre", " Hay una peque�a llave dorada en su interior.\n");
			s3.setDescripcion("\n Un altar de �bano ocupa el centro de la sala.\n Hay un cofre abierto detr�s del altar.\n Se puede salir por el sur.");
		}
		else if (salaActual.getNombre().equals(s4.getNombre()) && i2.getRecogido() == true && i2.getUsado() == false && atributo.equalsIgnoreCase(i2.getNombre())) {
			i2.setUsado(true);
			textArea.append("\n Has usado la llave.\n La rejilla del alcantarillado se abre.");
			textArea.append("\n\n �HAS ESCAPADO DE LA MAZMORRA, ENHORABUENA!\n");
			textField.setText(" Pulsa ENTER aqu� para salir");
		}
		else {
			textArea.append("\n No s� si eso se puede usar...\n");
		}
	}
	
	
	
	public void comandoAyuda() {
		textArea.setText("\n Hola, parece que est�s perdido. He aqu� la lista de los\n comandos que puedes usar:\n");
		textArea.append("\n - Examinar -> Permite examinar el entorno.   -> \"examinar piedra\"");
		textArea.append("\n - Coger    -> Permite coger objetos.         -> \"coger piedra\"");
		textArea.append("\n - Usar     -> Permite usar objetos.          -> \"usar piedra\"");
		textArea.append("\n - Ir       -> Permite moverse por las salas. -> \"ir norte\"\n");
		textArea.append("\n OBJETIVO DEL JUEGO: Usar una serie de objetos en un \n determinado orden para escapar de la mazmorra.\n");
		textArea.append("\n �Buena suerte!\n");
	}
}
