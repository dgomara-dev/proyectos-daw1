import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Sala {

	private String nombre;
	private String descripcion;
	private ArrayList<Salida> listaSalidas;
	private Map<String, String> diccionarioDescripciones;
	private Item item;

	public Sala(String nombre, String descripcion) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		listaSalidas = new ArrayList<Salida>();
		diccionarioDescripciones = new HashMap<String, String>();
		item = null;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public ArrayList<Salida> getListaSalidas() {
		return listaSalidas;
	}
	
	public Map<String, String> getDiccionarioDescripciones() {
		return diccionarioDescripciones;
	}
	
	public Item getItem() {
		return item;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void addSalida(Salida salida) {
		listaSalidas.add(salida);
	}
	
	public void addDescripcion(String nombre, String descripcion) {
		diccionarioDescripciones.put(nombre, descripcion);
	}
	
	public void setItem(Item item) {
		this.item = item;
	}
}
