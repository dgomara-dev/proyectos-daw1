
public class Salida {
	
	public static final int NORTE = 0;
	public static final int SUR = 1;
	public static final int ESTE = 2;
	public static final int OESTE = 3;
	public final String[] nombreDireccionVector = {"norte", "sur", "este", "oeste"};

	private String nombreDireccion;
	private Sala llevaA;	

	public Salida(int direccion, Sala llevaA) {
		nombreDireccion = nombreDireccionVector[direccion];
		this.llevaA = llevaA;
	}
	
	public Salida() {
	}
	
	public String[] getNombreDireccionVector() {
		return nombreDireccionVector;
	}
	
	public String getNombreDireccion() {
		return nombreDireccion;
	}	
	
	public Sala getLlevaA() {
		return llevaA;
	}	
}
