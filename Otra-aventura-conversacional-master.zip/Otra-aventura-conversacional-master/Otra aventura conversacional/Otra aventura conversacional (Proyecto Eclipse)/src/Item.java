
public class Item {
	
	private String nombre;
	private String descripcion;
	private boolean recogido;
	private boolean usado;
	
	public Item(String nombre, String descripcion) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		recogido = false;
		usado = false;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public boolean getRecogido() {
		return recogido;
	}
	
	public boolean getUsado() {
		return usado;
	}
	
	public void setRecogido(boolean recogido) {
		this.recogido = recogido;
	}
	
	public void setUsado(boolean usado) {
		this.usado = usado;
	}
}
